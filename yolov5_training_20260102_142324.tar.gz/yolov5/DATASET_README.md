# Plumbing Parts Dataset

## Dataset Overview

This dataset contains images of three types of plumbing parts:
- **Elbow** (class 0): Pipe elbow fittings
- **Fitting** (class 1): Pipe fittings
- **Valve** (class 2): Valves

## Dataset Structure

```
datasets/plumbing_parts/
├── train/
│   ├── images/     # 24 training images (8 per class)
│   └── labels/     # 24 label files (.txt format)
└── val/
    ├── images/     # 6 validation images (2 per class)
    └── labels/     # 6 label files (.txt format)
```

## Statistics

- **Total images**: 30
- **Training images**: 24 (8 elbow, 8 fitting, 8 valve)
- **Validation images**: 6 (2 elbow, 2 fitting, 2 valve)
- **Classes**: 3 (elbow, fitting, valve)

## Important Notes

⚠️ **The current labels are PLACEHOLDERS!**

The label files currently contain dummy annotations. You **MUST** replace them with real annotations before training:

1. **Install LabelImg** (annotation tool):
   ```bash
   pip install labelImg
   labelImg
   ```

2. **Annotate your images**:
   - Open LabelImg
   - Set format to "YOLO"
   - Load your images from `datasets/plumbing_parts/train/images/`
   - Draw bounding boxes around each object
   - Save labels (they'll be saved to the `labels/` directory)

3. **Class IDs**:
   - 0 = elbow
   - 1 = fitting
   - 2 = valve

4. **Label Format** (YOLO):
   ```
   class_id x_center y_center width height
   ```
   All values normalized (0-1)

## Using This Dataset

The notebook (`tutorial.ipynb`) is already configured to use this dataset. Just:

1. **Annotate the images** (see above)
2. **Run the notebook cells** in order
3. **Train** using cell 15

## Image Sources

Images were downloaded from the internet. Some are real photos, some are placeholder images created programmatically. For production use, you should:

- Use high-quality, diverse images
- Ensure proper lighting and angles
- Include various backgrounds and contexts
- Have multiple examples of each class

## Next Steps

1. ✅ Dataset structure created
2. ✅ Images downloaded
3. ⚠️ **Annotate images** (REQUIRED before training)
4. ⚠️ **Replace placeholder labels** with real annotations
5. ✅ Ready to train (after annotation)

