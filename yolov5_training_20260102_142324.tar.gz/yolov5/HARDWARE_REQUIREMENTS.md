# Hardware Requirements & Training Estimates

## Overview

This document provides hardware requirements and training time estimates for training YOLOv5 on custom datasets with approximately 300 images.

## Hardware Requirements

### Minimum Requirements (CPU Training)

**For small-scale testing or CPU-only training:**

- **CPU**: 4+ cores (Intel i5 or AMD Ryzen 5 equivalent)
- **RAM**: 8 GB minimum, 16 GB recommended
- **Storage**: 10-15 GB free space
  - YOLOv5 codebase: ~25 MB
  - Dataset (300 images): ~100-500 MB (depends on image resolution)
  - Model weights: ~15-50 MB per model
  - Training checkpoints: ~50-200 MB
  - Cache files: ~500 MB - 2 GB (optional, can be disabled)
- **GPU**: Not required (but training will be very slow - 10-50x slower)

**Training Time (CPU only):**
- 50 epochs: ~5-15 hours
- 100 epochs: ~10-30 hours
- ⚠️ **Not recommended for production training**

### Recommended Requirements (GPU Training)

**For efficient training with GPU:**

- **CPU**: 4+ cores (any modern CPU)
- **RAM**: 16 GB minimum, 32 GB recommended
- **Storage**: 20-30 GB free space
  - YOLOv5 codebase: ~25 MB
  - Dataset (300 images): ~100-500 MB
  - Model weights: ~15-50 MB per model
  - Training checkpoints: ~50-200 MB
  - Cache files: ~1-3 GB (optional)
  - Training logs/results: ~100-500 MB
- **GPU**:
  - **Minimum**: NVIDIA GPU with 4 GB VRAM (GTX 1050 Ti, GTX 1650)
  - **Recommended**: NVIDIA GPU with 8+ GB VRAM (RTX 3060, RTX 3070, RTX 4060, etc.)
  - **Optimal**: NVIDIA GPU with 16+ GB VRAM (RTX 3080, RTX 4080, A100, etc.)

### GPU Memory Requirements by Model Size

| Model | VRAM (Batch=16) | VRAM (Batch=32) | Recommended GPU |
|-------|----------------|-----------------|-----------------|
| YOLOv5n | 2-3 GB | 3-4 GB | GTX 1050 Ti, GTX 1650 |
| YOLOv5s | 3-4 GB | 5-6 GB | GTX 1660, RTX 2060 |
| YOLOv5m | 5-6 GB | 8-10 GB | RTX 3060, RTX 3070 |
| YOLOv5l | 8-10 GB | 12-14 GB | RTX 3070, RTX 3080 |
| YOLOv5x | 12-14 GB | 18-20 GB | RTX 3080, RTX 4080, A100 |

**Note**: Batch sizes can be reduced if you have less VRAM. Use `--batch 8` or `--batch 4` for smaller GPUs.

## Training Time Estimates

### For 300 Images (19 SKU Categories - Classification)

**With GPU (RTX 3060 / RTX 3070):**

| Model | Epochs | Batch Size | Training Time | Time to 80% Accuracy* |
|-------|--------|------------|---------------|----------------------|
| YOLOv5n-cls | 50 | 32 | ~15-30 min | ~10-20 min (20-30 epochs) |
| YOLOv5s-cls | 50 | 32 | ~20-40 min | ~15-30 min (20-30 epochs) |
| YOLOv5m-cls | 50 | 32 | ~30-60 min | ~20-40 min (20-30 epochs) |
| YOLOv5l-cls | 50 | 16 | ~45-90 min | ~30-60 min (20-30 epochs) |

**With GPU (RTX 3080 / RTX 4080):**

| Model | Epochs | Batch Size | Training Time | Time to 80% Accuracy* |
|-------|--------|------------|---------------|----------------------|
| YOLOv5n-cls | 50 | 64 | ~10-20 min | ~7-15 min (20-30 epochs) |
| YOLOv5s-cls | 50 | 64 | ~15-30 min | ~10-20 min (20-30 epochs) |
| YOLOv5m-cls | 50 | 32 | ~20-40 min | ~15-25 min (20-30 epochs) |
| YOLOv5l-cls | 50 | 32 | ~30-60 min | ~20-40 min (20-30 epochs) |

**With CPU (Intel i7 / AMD Ryzen 7):**

| Model | Epochs | Batch Size | Training Time | Time to 80% Accuracy* |
|-------|--------|------------|---------------|----------------------|
| YOLOv5n-cls | 50 | 8 | ~3-6 hours | ~2-4 hours (20-30 epochs) |
| YOLOv5s-cls | 50 | 8 | ~4-8 hours | ~3-5 hours (20-30 epochs) |
| YOLOv5m-cls | 50 | 4 | ~6-12 hours | ~4-8 hours (20-30 epochs) |

*Note: "80% accuracy" assumes good quality, balanced dataset. Actual time may vary.

### For 300 Images (Object Detection)

**With GPU (RTX 3060 / RTX 3070):**

| Model | Epochs | Batch Size | Training Time | Time to 80% mAP* |
|-------|--------|------------|---------------|------------------|
| YOLOv5n | 50 | 16 | ~30-60 min | ~20-40 min (20-30 epochs) |
| YOLOv5s | 50 | 16 | ~40-80 min | ~25-50 min (20-30 epochs) |
| YOLOv5m | 50 | 8 | ~60-120 min | ~40-80 min (20-30 epochs) |

*Note: mAP (mean Average Precision) is the metric for object detection. 80% mAP is excellent performance.

## Factors Affecting Training Time

1. **Dataset Size**: More images = longer training time (roughly linear)
2. **Image Resolution**: Larger images = longer training time
   - 224x224 (classification): Fastest
   - 640x640 (detection): Standard
   - 1280x1280: ~4x slower than 640x640
3. **Model Size**: Larger models = longer training time
   - YOLOv5n: Fastest
   - YOLOv5s: ~1.5x slower
   - YOLOv5m: ~2-3x slower
   - YOLOv5l: ~3-4x slower
4. **Batch Size**: Larger batches = faster training (but need more VRAM)
5. **GPU Performance**: Better GPU = faster training
6. **Training from Scratch vs Transfer Learning**:
   - Transfer learning: Faster convergence (reach 80% in 20-30 epochs)
   - From scratch: Slower convergence (may need 50-100 epochs)

## Storage Breakdown

### During Training

```
yolov5/                          ~25 MB
datasets/your_dataset/           ~100-500 MB (300 images)
runs/train/experiment/            ~100-500 MB (checkpoints, logs, plots)
  ├── weights/
  │   ├── best.pt                ~15-50 MB
  │   └── last.pt                ~15-50 MB
  ├── results.png                ~1-5 MB
  └── ... (other logs)            ~50-200 MB
```

**Total during training**: ~500 MB - 2 GB

### After Training (Cleanup)

You can delete:
- `runs/train/experiment/weights/last.pt` (keep only `best.pt`)
- Cache files (if using `--cache`)
- Intermediate checkpoints

**Total after cleanup**: ~200-500 MB

## Performance Tips

1. **Use Transfer Learning**: Start from pretrained weights (`yolov5s-cls.pt`) instead of training from scratch
2. **Optimize Batch Size**: Use the largest batch size that fits in your GPU memory
3. **Use Cache**: Enable `--cache` flag to cache images in RAM (faster, but uses more RAM)
4. **Reduce Image Size**: For classification, 224x224 is sufficient (faster than 640x640)
5. **Use Smaller Model**: YOLOv5n or YOLOv5s are often sufficient for 300 images
6. **Early Stopping**: Monitor validation accuracy and stop when it plateaus

## Example: Training 300 Images on RTX 3060

**Scenario**: 300 images, 19 SKU categories, classification task

**Recommended Setup**:
```bash
python classify/train.py \
  --data datasets/sku_classification \
  --model yolov5s-cls.pt \
  --epochs 50 \
  --img 224 \
  --batch 32 \
  --name sku_classification
```

**Expected Results**:
- Training time: ~20-40 minutes
- Time to 80% accuracy: ~15-30 minutes (20-30 epochs)
- Storage used: ~500 MB - 1 GB
- VRAM used: ~3-4 GB

## Cloud Training Options

If you don't have a GPU locally:

1. **Google Colab** (Free):
   - Free GPU: Tesla T4 (16 GB VRAM)
   - Training time: Similar to RTX 3060
   - Storage: 15 GB free

2. **Kaggle** (Free):
   - Free GPU: P100 (16 GB VRAM)
   - Training time: Similar to RTX 3060
   - Storage: 5 GB free

3. **AWS/GCP/Azure** (Paid):
   - Various GPU options
   - Pay per hour (~$0.50-$3/hour for GPU instances)

## Summary

**For 300 images, 19 SKU categories:**

- **Minimum**: 8 GB RAM, 10 GB storage, CPU (slow but works)
- **Recommended**: 16 GB RAM, 20 GB storage, GPU with 4+ GB VRAM
- **Optimal**: 32 GB RAM, 30 GB storage, GPU with 8+ GB VRAM

**Training Time to 80% Performance:**
- **GPU (RTX 3060)**: 15-30 minutes
- **GPU (RTX 3080)**: 10-20 minutes
- **CPU**: 2-4 hours

**Storage Needed:**
- **During training**: ~500 MB - 2 GB
- **After cleanup**: ~200-500 MB

---

*These estimates are based on typical scenarios. Actual results may vary based on image complexity, dataset quality, and hardware configuration.*

