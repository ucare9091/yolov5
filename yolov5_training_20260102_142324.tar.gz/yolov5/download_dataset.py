#!/usr/bin/env python3
"""
Download images for YOLOv5 custom dataset
Downloads images for: elbow, fitting, and valve
"""

import os
import requests
from pathlib import Path
from urllib.parse import urlparse
import time

# Dataset configuration
DATASET_NAME = "plumbing_parts"
BASE_DIR = Path("datasets") / DATASET_NAME
TRAIN_IMAGES = BASE_DIR / "train" / "images"
VAL_IMAGES = BASE_DIR / "val" / "images"

# Create directories
TRAIN_IMAGES.mkdir(parents=True, exist_ok=True)
VAL_IMAGES.mkdir(parents=True, exist_ok=True)

# Image URLs - using Unsplash and other free image sources
# These are sample URLs - you may need to update them if they don't work
IMAGE_URLS = {
    "elbow": [
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800",
        "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800",
        "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800",
        "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800",
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800",
        "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800",
        "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800",
        "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800",
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800",
        "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800",
    ],
    "fitting": [
        "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800",
        "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800",
        "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800",
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800",
        "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800",
        "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800",
        "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800",
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800",
        "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800",
        "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800",
    ],
    "valve": [
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800",
        "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800",
        "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800",
        "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800",
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800",
        "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800",
        "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800",
        "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800",
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800",
        "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800",
    ]
}

# Better approach: Use a search API or download from specific sources
# Let's use a more reliable method with placeholder images or direct downloads

def download_image(url, save_path, class_name, idx):
    """Download an image from URL"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            with open(save_path, 'wb') as f:
                f.write(response.content)
            print(f"✅ Downloaded {class_name} image {idx+1}: {save_path.name}")
            return True
        else:
            print(f"❌ Failed to download {class_name} image {idx+1}: Status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error downloading {class_name} image {idx+1}: {e}")
        return False

def create_placeholder_image(save_path, class_name, idx):
    """Create a placeholder image using PIL"""
    try:
        from PIL import Image, ImageDraw, ImageFont
        import random

        # Create a simple colored image with text
        img = Image.new('RGB', (640, 480), color=(random.randint(100, 255),
                                                   random.randint(100, 255),
                                                   random.randint(100, 255)))
        draw = ImageDraw.Draw(img)

        # Add text
        text = f"{class_name}\n{idx+1}"
        # Try to use a default font
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 40)
        except:
            font = ImageFont.load_default()

        # Get text bounding box
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]

        # Center the text
        position = ((640 - text_width) // 2, (480 - text_height) // 2)
        draw.text(position, text, fill=(0, 0, 0), font=font)

        img.save(save_path)
        print(f"✅ Created placeholder {class_name} image {idx+1}: {save_path.name}")
        return True
    except Exception as e:
        print(f"❌ Error creating placeholder {class_name} image {idx+1}: {e}")
        return False

def main():
    print("="*70)
    print("Downloading/Creating Dataset Images")
    print("="*70)
    print()

    # Class mapping
    classes = ["elbow", "fitting", "valve"]
    class_to_id = {cls: idx for idx, cls in enumerate(classes)}

    total_downloaded = 0
    total_created = 0

    # Download/Create images for each class
    for class_name in classes:
        print(f"\n📦 Processing {class_name} images...")
        class_id = class_to_id[class_name]

        # Download 8 images for training
        for idx in range(8):
            filename = f"{class_name}_{idx+1:02d}.jpg"
            save_path = TRAIN_IMAGES / filename

            # Try to download, if fails create placeholder
            if not download_image(IMAGE_URLS[class_name][idx], save_path, class_name, idx):
                if create_placeholder_image(save_path, class_name, idx):
                    total_created += 1
                else:
                    print(f"⚠️  Skipping {filename}")
            else:
                total_downloaded += 1
            time.sleep(0.5)  # Be nice to servers

        # Download 2 images for validation
        for idx in range(2):
            filename = f"{class_name}_val_{idx+1:02d}.jpg"
            save_path = VAL_IMAGES / filename
            url_idx = 8 + idx

            if not download_image(IMAGE_URLS[class_name][url_idx], save_path, class_name, idx):
                if create_placeholder_image(save_path, class_name, idx):
                    total_created += 1
                else:
                    print(f"⚠️  Skipping {filename}")
            else:
                total_downloaded += 1
            time.sleep(0.5)

    print()
    print("="*70)
    print(f"✅ Dataset creation complete!")
    print(f"   Downloaded: {total_downloaded} images")
    print(f"   Created placeholders: {total_created} images")
    print(f"   Total: {total_downloaded + total_created} images")
    print()
    print(f"📁 Dataset location: {BASE_DIR.absolute()}")
    print()
    print("⚠️  NOTE: You still need to:")
    print("   1. Create label files (.txt) for each image")
    print("   2. Use an annotation tool like LabelImg to annotate the images")
    print("   3. Labels should be in YOLO format: class_id x_center y_center width height")
    print("="*70)

if __name__ == "__main__":
    main()

