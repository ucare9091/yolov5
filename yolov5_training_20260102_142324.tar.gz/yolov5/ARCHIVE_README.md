# YOLOv5 Custom Training Archive

## Quick Start

1. **Extract the archive:**
   ```bash
   tar -xzf yolov5_custom_training.tar.gz
   cd yolov5
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Open the tutorial notebook:**
   ```bash
   jupyter notebook tutorial.ipynb
   # or
   jupyter lab tutorial.ipynb
   ```

4. **Follow the notebook cells** to train on your custom dataset!

## What's Included

- ✅ **Tutorial Notebook** (`tutorial.ipynb`) - Complete training guide
- ✅ **SKU Classification Guide** (`SKU_CLASSIFICATION_GUIDE.md`) - For 19 SKU categories
- ✅ **Custom Training Guide** (`CUSTOM_TRAINING_GUIDE.md`) - For object detection
- ✅ **Hardware Requirements** (`HARDWARE_REQUIREMENTS.md`) - System requirements & training time estimates
- ✅ **Agent Review** (`AGENT_REVIEW.md`) - Overview of capabilities
- ✅ All YOLOv5 training scripts (detection, classification, segmentation)
- ✅ Dataset configuration files and examples

## Features

- 🎯 **Classification Mode**: Train on 19 SKU categories (no bounding boxes needed!)
- 🎯 **Detection Mode**: Train with bounding boxes for object detection
- 🚀 **Training from Scratch**: Full training from random initialization
- 🚀 **Transfer Learning**: Faster training from pretrained weights
- 📊 **Fully Portable**: All paths are relative - works anywhere!

## Documentation

- **SKU_CLASSIFICATION_GUIDE.md** - Complete guide for image classification
- **CUSTOM_TRAINING_GUIDE.md** - Guide for object detection
- **HARDWARE_REQUIREMENTS.md** - System requirements & training time estimates
- **AGENT_REVIEW.md** - Overview and quick start

## Requirements

See `HARDWARE_REQUIREMENTS.md` for detailed requirements.

**Quick Summary:**
- **Minimum**: 8 GB RAM, 10 GB storage, CPU (slow)
- **Recommended**: 16 GB RAM, 20 GB storage, GPU with 4+ GB VRAM
- **Training Time** (300 images, 19 categories): 15-30 minutes on RTX 3060

## Usage

### For Classification (19 SKU Categories)

1. Organize images in folders: `datasets/sku_classification/train/SKU_001/`, etc.
2. Open `tutorial.ipynb`
3. Set `TASK_TYPE = "classification"` in Cell 11
4. Update `SKU_CATEGORIES` with your 19 category names
5. Run cells to train!

### For Detection (Bounding Boxes)

1. Organize images and labels: `datasets/your_dataset/train/images/` and `train/labels/`
2. Open `tutorial.ipynb`
3. Set `TASK_TYPE = "detection"` in Cell 11
4. Configure your dataset
5. Run cells to train!

## Notes

- Model weights (`.pt` files) are NOT included - they will be downloaded automatically
- Training results (`runs/` directory) are NOT included - will be created during training
- All paths are relative - works on any system!

## Support

- YOLOv5 Docs: https://docs.ultralytics.com/yolov5/
- GitHub Issues: https://github.com/ultralytics/yolov5/issues
- Discord: https://discord.com/invite/ultralytics

---

**Ready to train!** 🚀

