# Why Notebook Cells Run Slowly & How to Fix It

## Main Reasons for Slow Execution

### 1. **CPU-Only PyTorch** (Main Issue!)
Your environment has **PyTorch CPU version** (no GPU acceleration):
- PyTorch: 2.9.1+cpu
- CUDA: Not available
- **This makes everything 10-100x slower than GPU**

### 2. **First-Time Imports**
First time importing YOLOv5 modules can be slow:
- Loading all dependencies
- Initializing CUDA (even if not available)
- Checking for updates

### 3. **Model Downloads**
If models need to be downloaded, that takes time:
- yolov5s.pt is ~14MB
- First download can be slow

### 4. **Heavy Initialization**
`utils.notebook_init()` does a lot of checks:
- System info gathering
- Git status checks
- Update checks
- Device detection

## Quick Fixes

### Option 1: Skip Heavy Initialization (Fastest)

Replace Cell 2 with this lighter version:

```python
import os
import sys
from pathlib import Path

# Change to yolov5 directory
os.chdir('/home/chlj/nvspark/yolov5')
print(f"Working directory: {os.getcwd()}")

# Lightweight imports (skip heavy notebook_init)
import torch
print(f"PyTorch: {torch.__version__}")
print(f"CUDA available: {torch.cuda.is_available()}")
print(f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}")

# Import utils but skip the heavy init
import utils
print("✅ Setup complete")
```

### Option 2: Pre-download Models

Download models before running cells:

```bash
cd /home/chlj/nvspark/yolov5
source ../agenttorch_env/bin/activate
python -c "from utils.downloads import attempt_download; attempt_download('yolov5s.pt')"
```

### Option 3: Use GPU PyTorch (Best Performance)

If you have a GPU, install GPU-enabled PyTorch:

```bash
# Uninstall CPU version
pip uninstall torch torchvision torchaudio -y

# Install GPU version (adjust CUDA version as needed)
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

**Note**: Only do this if you have an NVIDIA GPU with CUDA support.

### Option 4: Reduce Batch Size

When training, use smaller batch sizes for CPU:
- Change `--batch 16` to `--batch 4` or `--batch 2`
- This prevents out-of-memory and runs faster on CPU

## Expected Performance

### CPU (Your Current Setup)
- Cell 2 (imports): 5-15 seconds (first time)
- Cell 2 (imports): 2-5 seconds (subsequent runs)
- Detection: 50-200ms per image
- Training: Very slow (hours for 50 epochs)

### GPU (If Available)
- Cell 2 (imports): 3-8 seconds (first time)
- Cell 2 (imports): 1-3 seconds (subsequent runs)
- Detection: 5-20ms per image
- Training: Much faster (minutes for 50 epochs)

## What's Normal?

- **First cell run**: 5-15 seconds is normal (imports + initialization)
- **Subsequent runs**: 2-5 seconds is normal
- **If it takes >30 seconds**: Something is wrong

## Troubleshooting

### If Cell 2 Takes Forever

1. **Check if it's stuck**: Look for any error messages
2. **Try interrupting**: Press the stop button (⏹) in VSCode
3. **Restart kernel**: Use "Restart Kernel" option
4. **Skip notebook_init**: Use the lighter version above

### If Training is Slow

This is **expected** on CPU:
- CPU training is 10-100x slower than GPU
- Consider:
  - Using fewer epochs for testing
  - Using smaller models (yolov5n instead of yolov5s)
  - Using smaller image sizes (416 instead of 640)
  - Training on a GPU machine

## Quick Test

Run this to see import speed:

```python
import time
start = time.time()
import torch
import utils
print(f"Import took: {time.time() - start:.2f} seconds")
```

If it's >20 seconds, there might be a network issue (checking for updates).

## Summary

**Your setup is CPU-only, which is slow but functional:**
- ✅ Will work for testing and small datasets
- ⚠️ Training will be very slow
- 💡 Use GPU if available for faster training

**For now**: Use the lighter Cell 2 version to speed up notebook startup!

