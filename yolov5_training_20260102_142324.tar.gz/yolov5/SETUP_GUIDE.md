# Setup Guide - Getting Started

## Quick Start

### 1. Extract Archive

```bash
tar -xzf yolov5_custom_training.tar.gz
cd yolov5
```

### 2. Create Virtual Environment (Recommended)

**Why use a virtual environment?**
- Isolates packages from other projects
- Prevents conflicts between different Python projects
- Easy to delete and recreate

**Create virtual environment:**

```bash
# Create virtual environment
python3 -m venv yolov5_env

# Activate it
# On Linux/Mac:
source yolov5_env/bin/activate

# On Windows:
yolov5_env\Scripts\activate
```

You should see `(yolov5_env)` in your terminal prompt.

### 3. Install Dependencies

```bash
# Make sure virtual environment is activated (you should see yolov5_env in prompt)
pip install --upgrade pip
pip install -r requirements.txt

# Also install Jupyter for notebook support
pip install jupyter ipykernel
```

### 4. Run the Notebook

**Option A: Jupyter Notebook (Browser)**

```bash
# Make sure virtual environment is activated
jupyter notebook tutorial.ipynb
```

**Option B: VS Code (Recommended)**

See VS Code setup section below.

**Option C: JupyterLab**

```bash
pip install jupyterlab
jupyter lab tutorial.ipynb
```

---

## VS Code Setup

### Prerequisites

1. **Install VS Code**: https://code.visualstudio.com/
2. **Install Jupyter Extension**:
   - Open VS Code
   - Press `Ctrl+Shift+X` (or `Cmd+Shift+X` on Mac) to open Extensions
   - Search for "Jupyter" (by Microsoft)
   - Click "Install"

### Steps to Run Notebook in VS Code

1. **Open the Project**:
   ```bash
   cd yolov5
   code .
   ```

2. **Open the Notebook**:
   - In VS Code, open `tutorial.ipynb`
   - Or use: `File > Open File > tutorial.ipynb`

3. **Select Python Interpreter**:
   - Click the kernel selector in the top right of the notebook
   - Choose your Python interpreter:
     - **If using virtual environment**: Select `yolov5_env/bin/python` (or `yolov5_env\Scripts\python.exe` on Windows)
     - **If not using virtual environment**: Select your system Python

4. **Register Virtual Environment Kernel (Optional but Recommended)**:
   ```bash
   # Activate virtual environment first
   source yolov5_env/bin/activate  # Linux/Mac
   # or
   yolov5_env\Scripts\activate  # Windows

   # Register kernel
   python -m ipykernel install --user --name=yolov5_env --display-name "Python (yolov5_env)"
   ```

   Now you can select "Python (yolov5_env)" from the kernel selector in VS Code.

5. **Run Cells**:
   - Click "Run" button on each cell
   - Or use keyboard shortcuts:
     - `Shift+Enter` - Run cell and move to next
     - `Ctrl+Enter` - Run cell and stay
     - `Alt+Enter` - Run cell and insert new cell below

### VS Code Features

- ✅ Interactive cell execution
- ✅ Variable explorer
- ✅ Plot visualization
- ✅ IntelliSense/autocomplete
- ✅ Git integration
- ✅ Debugging support
- ✅ Integrated terminal

### Troubleshooting VS Code

**Problem: Can't select Python interpreter**
- Solution: Install Python extension in VS Code
- Press `Ctrl+Shift+X`, search "Python" (by Microsoft), install

**Problem: Cells won't run**
- Check Python interpreter is selected (top right of notebook)
- Make sure Jupyter extension is installed
- Try: `pip install jupyter ipykernel` in your virtual environment
- Restart VS Code

**Problem: Import errors**
- Make sure virtual environment is activated
- Make sure you're in the yolov5 root directory
- Check Output panel in VS Code for errors

---

## Complete Setup Script

Create a `setup.sh` file (Linux/Mac) or `setup.bat` (Windows):

### Linux/Mac (`setup.sh`):

```bash
#!/bin/bash

echo "🚀 Setting up YOLOv5 Custom Training..."

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv yolov5_env

# Activate
echo "✅ Activating virtual environment..."
source yolov5_env/bin/activate

# Upgrade pip
echo "⬆️  Upgrading pip..."
pip install --upgrade pip

# Install dependencies
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Install Jupyter
echo "📓 Installing Jupyter..."
pip install jupyter ipykernel

# Register kernel
echo "🔧 Registering Jupyter kernel..."
python -m ipykernel install --user --name=yolov5_env --display-name "Python (yolov5_env)"

echo ""
echo "✅ Setup complete!"
echo ""
echo "To activate virtual environment:"
echo "  source yolov5_env/bin/activate"
echo ""
echo "To run notebook in VS Code:"
echo "  1. Open VS Code: code ."
echo "  2. Open tutorial.ipynb"
echo "  3. Select kernel: Python (yolov5_env)"
echo ""
echo "To run notebook in browser:"
echo "  jupyter notebook tutorial.ipynb"
```

### Windows (`setup.bat`):

```batch
@echo off

echo 🚀 Setting up YOLOv5 Custom Training...

echo 📦 Creating virtual environment...
python -m venv yolov5_env

echo ✅ Activating virtual environment...
call yolov5_env\Scripts\activate.bat

echo ⬆️  Upgrading pip...
python -m pip install --upgrade pip

echo 📥 Installing dependencies...
pip install -r requirements.txt

echo 📓 Installing Jupyter...
pip install jupyter ipykernel

echo 🔧 Registering Jupyter kernel...
python -m ipykernel install --user --name=yolov5_env --display-name "Python (yolov5_env)"

echo.
echo ✅ Setup complete!
echo.
echo To activate virtual environment:
echo   yolov5_env\Scripts\activate
echo.
echo To run notebook in VS Code:
echo   1. Open VS Code: code .
echo   2. Open tutorial.ipynb
echo   3. Select kernel: Python (yolov5_env)
echo.
pause
```

**Run the script:**
```bash
# Linux/Mac
chmod +x setup.sh
./setup.sh

# Windows
setup.bat
```

---

## Verification

After setup, verify everything works:

```bash
# Activate virtual environment
source yolov5_env/bin/activate  # Linux/Mac
# or
yolov5_env\Scripts\activate  # Windows

# Check Python
python --version

# Check packages
pip list | grep torch
pip list | grep jupyter

# Test import
python -c "import torch; print(f'PyTorch: {torch.__version__}')"
python -c "import jupyter; print('Jupyter installed')"
```

---

## Common Issues

### Issue: "python3: command not found"
**Solution**: Use `python` instead of `python3`, or install Python 3

### Issue: "pip: command not found"
**Solution**: Install pip or use `python -m pip` instead

### Issue: "Permission denied" when installing
**Solution**: Don't use `sudo` with virtual environments. Make sure virtual environment is activated.

### Issue: VS Code can't find kernel
**Solution**:
1. Make sure virtual environment is activated
2. Run: `python -m ipykernel install --user --name=yolov5_env`
3. Restart VS Code
4. Select kernel from top right of notebook

### Issue: "Module not found" errors
**Solution**:
1. Make sure virtual environment is activated
2. Make sure you're in yolov5 root directory
3. Run: `pip install -r requirements.txt` again

---

## Next Steps

After setup is complete:

1. **Organize your dataset** (see `SKU_CLASSIFICATION_GUIDE.md` or `CUSTOM_TRAINING_GUIDE.md`)
2. **Open tutorial.ipynb** in VS Code or Jupyter
3. **Configure your dataset** in Cell 11
4. **Run cells** to train your model!

---

**Need help?** Check the other guides:
- `SKU_CLASSIFICATION_GUIDE.md` - For 19 SKU categories
- `CUSTOM_TRAINING_GUIDE.md` - For object detection
- `HARDWARE_REQUIREMENTS.md` - System requirements

