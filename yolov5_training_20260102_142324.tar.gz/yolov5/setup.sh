#!/bin/bash

echo "🚀 Setting up YOLOv5 Custom Training..."

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv yolov5_env

# Activate
echo "✅ Activating virtual environment..."
source yolov5_env/bin/activate

# Upgrade pip
echo "⬆️  Upgrading pip..."
pip install --upgrade pip

# Install dependencies
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Install Jupyter
echo "📓 Installing Jupyter..."
pip install jupyter ipykernel

# Register kernel
echo "🔧 Registering Jupyter kernel..."
python -m ipykernel install --user --name=yolov5_env --display-name "Python (yolov5_env)"

echo ""
echo "✅ Setup complete!"
echo ""
echo "To activate virtual environment:"
echo "  source yolov5_env/bin/activate"
echo ""
echo "To run notebook in VS Code:"
echo "  1. Open VS Code: code ."
echo "  2. Open tutorial.ipynb"
echo "  3. Select kernel: Python (yolov5_env)"
echo ""
echo "To run notebook in browser:"
echo "  jupyter notebook tutorial.ipynb"
