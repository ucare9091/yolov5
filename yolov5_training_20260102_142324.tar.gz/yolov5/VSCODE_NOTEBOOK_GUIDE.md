# Running tutorial.ipynb in VSCode

## Quick Answer

**Yes, you can run the notebook directly in VSCode!**

**Select this environment when VSCode asks:**
```
/home/chlj/nvspark/agenttorch_env/bin/python
```

## Step-by-Step Instructions

### 1. Install VSCode Extensions (if not already installed)

Make sure you have the **Jupyter extension** installed:
- Open VSCode
- Go to Extensions (Ctrl+Shift+X)
- Search for "Jupyter" by Microsoft
- Install it if not already installed

### 2. Open the Notebook

1. In VSCode, open the file: `/home/chlj/nvspark/yolov5/tutorial.ipynb`
2. VSCode will automatically recognize it as a Jupyter notebook

### 3. Select the Python Environment

When you open the notebook, VSCode will show a prompt at the top:

**"Select Kernel"** or **"Select Python Environment"**

Click on it and choose:
```
Python 3.12.3 ('agenttorch_env': venv) /home/chlj/nvspark/agenttorch_env/bin/python
```

Or manually select:
- Click "Select Kernel" button (top right of notebook)
- Choose "Python Environments"
- Select: `/home/chlj/nvspark/agenttorch_env/bin/python`

### 4. Verify the Kernel

After selecting, you should see in the top right of the notebook:
```
Python 3.12.3 ('agenttorch_env': venv)
```

### 5. Run the Notebook

- **Run a single cell**: Click the "Run" button (▶) above the cell, or press `Shift+Enter`
- **Run all cells**: Click "Run All" in the toolbar
- **Run cells above/below**: Use the cell menu options

## Alternative: Set Default Kernel

To avoid selecting the kernel every time:

1. Open Command Palette: `Ctrl+Shift+P` (or `Cmd+Shift+P` on Mac)
2. Type: "Notebook: Select Notebook Kernel"
3. Select: `/home/chlj/nvspark/agenttorch_env/bin/python`
4. VSCode will remember this for future sessions

## Troubleshooting

### If VSCode doesn't show the kernel option:

1. **Check Python extension is installed**:
   - Install "Python" extension by Microsoft
   - Install "Jupyter" extension by Microsoft

2. **Manually register the kernel**:
   ```bash
   cd /home/chlj/nvspark
   source agenttorch_env/bin/activate
   python -m ipykernel install --user --name=agenttorch_env --display-name="Python (agenttorch_env)"
   ```
   Then restart VSCode and select "Python (agenttorch_env)"

### If you get import errors:

1. Make sure you selected the correct environment (agenttorch_env)
2. Check that the kernel shows `agenttorch_env` in the top right
3. Try restarting the kernel: Click "Restart Kernel" button

### If cells don't run:

1. Check that Jupyter is installed: `pip list | grep jupyter`
2. If not, install: `pip install jupyter ipykernel`
3. Restart VSCode

## Running from Terminal (Alternative)

If VSCode doesn't work, you can also run Jupyter in the browser:

```bash
cd /home/chlj/nvspark/yolov5
source ../agenttorch_env/bin/activate
jupyter notebook tutorial.ipynb
```

This will open the notebook in your web browser.

## Quick Reference

- **Environment path**: `/home/chlj/nvspark/agenttorch_env/bin/python`
- **Python version**: 3.12.3
- **Notebook location**: `/home/chlj/nvspark/yolov5/tutorial.ipynb`
- **Working directory**: Should be `/home/chlj/nvspark/yolov5` (notebook sets this automatically)

## First Time Setup

If this is your first time running notebooks in VSCode:

1. Install extensions: Python + Jupyter
2. Open the notebook
3. Select kernel: `/home/chlj/nvspark/agenttorch_env/bin/python`
4. Run the first cell to test
5. If it works, you're all set! ✅

