# YOLOv5 Custom Training Guide

This guide explains how to train YOLOv5 on your own custom images using the tutorial notebook.

## Quick Start

1. **Open the notebook**: `tutorial.ipynb`
2. **Run the setup cells** (cells 1-2) to verify your environment
3. **Prepare your dataset** (see Dataset Format below)
4. **Configure your dataset** in cell 11 (update `DATASET_NAME`, `DATASET_PATH`, and `CLASS_NAMES`)
5. **Verify dataset** using cell 13
6. **Train** using cell 15
7. **Test** your model using cell 17

## Dataset Format

Your dataset must be organized in the following structure:

```
datasets/
  my_custom_dataset/
    train/
      images/          # Training images (jpg, png, etc.)
      labels/          # Training labels (.txt files)
    val/
      images/          # Validation images
      labels/          # Validation labels (.txt files)
```

### Label Format

Each image must have a corresponding `.txt` file with the same name in the `labels/` directory.

**Label file format** (YOLO format):
```
class_id x_center y_center width height
```

All values are **normalized** (0-1):
- `class_id`: Integer class ID (0, 1, 2, ...)
- `x_center`: X coordinate of bounding box center (normalized by image width)
- `y_center`: Y coordinate of bounding box center (normalized by image height)
- `width`: Width of bounding box (normalized by image width)
- `height`: Height of bounding box (normalized by image height)

**Example label file** (`image001.txt`):
```
0 0.5 0.5 0.3 0.4
1 0.2 0.3 0.1 0.2
```

This means:
- Object of class 0 at center (0.5, 0.5) with size 0.3×0.4
- Object of class 1 at center (0.2, 0.3) with size 0.1×0.2

### Creating Labels

You can create labels using annotation tools like:
- **LabelImg**: https://github.com/tzutalin/labelImg
- **CVAT**: https://cvat.org/
- **Roboflow**: https://roboflow.com/
- **Label Studio**: https://labelstud.io/

## Configuration

In the notebook cell 11, update these variables:

```python
DATASET_NAME = "my_custom_dataset"  # Your dataset name
DATASET_PATH = Path("datasets") / DATASET_NAME  # Path to dataset

CLASS_NAMES = {
    0: "person",      # Your class names
    1: "car",
    2: "bicycle",
    # Add more classes...
}
```

## Training Parameters

Adjust these in cell 15:

- `--epochs`: Number of training epochs (start with 50-100)
- `--batch`: Batch size (16 is good for most GPUs, reduce if you get out-of-memory errors)
- `--img`: Image size (640 is standard, can use 416 or 1280)
- `--weights`: Pretrained model:
  - `yolov5s.pt` - Small (fastest, least accurate)
  - `yolov5m.pt` - Medium
  - `yolov5l.pt` - Large
  - `yolov5x.pt` - Extra Large (slowest, most accurate)

## Results

After training, results are saved to:
```
runs/train/{DATASET_NAME}/
  ├── weights/
  │   ├── best.pt      # Best model (highest mAP)
  │   └── last.pt      # Latest model
  ├── results.png      # Training curves
  ├── confusion_matrix.png
  └── ...
```

## Using Your Trained Model

```python
import torch

# Load your trained model
model = torch.hub.load('ultralytics/yolov5', 'custom',
                       path='runs/train/my_custom_dataset/weights/best.pt')

# Run inference
results = model('path/to/image.jpg')
results.show()  # Display results
results.save()  # Save results
```

## Troubleshooting

### Out of Memory (OOM) Errors
- Reduce `--batch` size (try 8, 4, or even 2)
- Reduce `--img` size (try 416 instead of 640)

### No Training Images Found
- Check that images are in `datasets/{DATASET_NAME}/train/images/`
- Verify image file extensions are supported (jpg, png, etc.)

### Label Mismatch
- Ensure each image has a corresponding `.txt` file in `labels/` directory
- Check that label files are in YOLO format (normalized 0-1)

### Training Not Starting
- Run the verification cell (cell 13) to check dataset structure
- Ensure all paths in the YAML config are correct

## Tips

1. **Start small**: Test with a small dataset first (50-100 images)
2. **Use pretrained weights**: Always start from `yolov5s.pt` for faster convergence
3. **Split your data**: Use 80% for training, 20% for validation
4. **Monitor training**: Check TensorBoard logs in `runs/train/`
5. **Data augmentation**: YOLOv5 automatically augments data during training

## Need Help?

- YOLOv5 Docs: https://docs.ultralytics.com/yolov5/
- GitHub Issues: https://github.com/ultralytics/yolov5/issues
- Discord: https://discord.com/invite/ultralytics

