#!/usr/bin/env python3
"""
Create placeholder label files for the dataset
These are dummy labels - you'll need to replace them with real annotations
"""

from pathlib import Path

DATASET_DIR = Path("datasets/plumbing_parts")

# Class mapping
CLASS_NAMES = ["elbow", "fitting", "valve"]
CLASS_TO_ID = {name: idx for idx, name in enumerate(CLASS_NAMES)}

def create_placeholder_label(image_path, class_name):
    """Create a placeholder label file"""
    label_dir = image_path.parent.parent / "labels"
    label_dir.mkdir(exist_ok=True)

    label_file = label_dir / (image_path.stem + ".txt")

    # Create a placeholder label (centered, medium-sized box)
    # Format: class_id x_center y_center width height (all normalized 0-1)
    class_id = CLASS_TO_ID[class_name]

    # Placeholder: object in center, 30% width, 40% height
    placeholder_label = f"{class_id} 0.5 0.5 0.3 0.4\n"

    with open(label_file, 'w') as f:
        f.write(placeholder_label)

    return label_file

def main():
    print("Creating placeholder label files...")
    print("⚠️  These are DUMMY labels - you MUST replace them with real annotations!")
    print()

    # Process train images
    train_images_dir = DATASET_DIR / "train" / "images"
    if train_images_dir.exists():
        for image_file in train_images_dir.glob("*.jpg"):
            # Extract class name from filename (e.g., "elbow_01.jpg" -> "elbow")
            class_name = image_file.stem.split('_')[0]
            if class_name in CLASS_TO_ID:
                label_file = create_placeholder_label(image_file, class_name)
                print(f"✅ Created: {label_file.name}")

    # Process val images
    val_images_dir = DATASET_DIR / "val" / "images"
    if val_images_dir.exists():
        for image_file in val_images_dir.glob("*.jpg"):
            # Extract class name from filename
            class_name = image_file.stem.split('_')[0]
            if class_name in CLASS_TO_ID:
                label_file = create_placeholder_label(image_file, class_name)
                print(f"✅ Created: {label_file.name}")

    print()
    print("="*70)
    print("✅ Placeholder labels created!")
    print()
    print("⚠️  IMPORTANT: These are placeholder labels!")
    print("   You MUST annotate your images using a tool like LabelImg")
    print("   and replace these placeholder labels with real annotations.")
    print()
    print("   Label format: class_id x_center y_center width height")
    print("   - class_id: 0=elbow, 1=fitting, 2=valve")
    print("   - All coordinates normalized (0-1)")
    print("="*70)

if __name__ == "__main__":
    main()

