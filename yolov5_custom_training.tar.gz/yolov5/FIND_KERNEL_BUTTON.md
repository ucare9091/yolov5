# How to Find "Select Kernel" in VSCode

The kernel selector button location varies by VSCode version. Here are all the ways to find it:

## Method 1: Top Right Corner (Most Common)

1. Open the notebook file: `tutorial.ipynb`
2. Look at the **top right** of the notebook editor
3. You should see text like:
   - "Select Kernel" (clickable link)
   - Or "Python 3.x.x" (click to change)
   - Or a kernel icon/button

## Method 2: Command Palette (Most Reliable)

1. Press `Ctrl+Shift+P` (or `Cmd+Shift+P` on Mac)
2. Type: `Notebook: Select Notebook Kernel`
3. Press Enter
4. Choose: `Python (agenttorch_env)` or `/home/chlj/nvspark/agenttorch_env/bin/python`

## Method 3: Status Bar (Bottom Right)

1. Look at the **bottom right** of VSCode window
2. You should see "Python 3.x.x" or "Select Kernel"
3. Click on it
4. Choose your environment

## Method 4: Right-Click in Notebook

1. Right-click anywhere in the notebook
2. Look for "Select Kernel" or "Change Kernel" option
3. Click it and choose your environment

## Method 5: Via Settings (If Button is Hidden)

1. Press `Ctrl+,` to open Settings
2. Search for: `jupyter.kernels`
3. Or search for: `notebook kernel`
4. Configure the default kernel there

## Method 6: Check Extensions

Make sure you have the right extensions:

1. Press `Ctrl+Shift+X` to open Extensions
2. Search for and install:
   - **"Jupyter"** by Microsoft (required!)
   - **"Python"** by Microsoft (required!)
3. Reload VSCode after installing

## Method 7: Manual Kernel Selection via JSON

If nothing works, you can manually set it:

1. Open Command Palette: `Ctrl+Shift+P`
2. Type: `Preferences: Open User Settings (JSON)`
3. Add this line:
   ```json
   "jupyter.kernels.filter": [],
   "python.defaultInterpreterPath": "/home/chlj/nvspark/agenttorch_env/bin/python"
   ```

## Visual Guide

The kernel selector typically appears in one of these locations:

```
┌─────────────────────────────────────────┐
│  File  Edit  ...                    [🔽] │ ← Top right (sometimes here)
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ # Your notebook cells            │   │
│  │                                  │   │
│  │ [▶ Run] [Select Kernel ▼]      │   │ ← Or here (toolbar)
│  └─────────────────────────────────┘   │
│                                         │
│  └─────────────────────────────────┘   │
│  Python 3.12.3 ▼                       │ ← Or bottom right (status bar)
└─────────────────────────────────────────┘
```

## Quick Test

After selecting the kernel, run this in a cell to verify:

```python
import sys
print("Python:", sys.executable)
```

It should show: `/home/chlj/nvspark/agenttorch_env/bin/python`

## Still Can't Find It?

1. **Check VSCode version**: Update to latest version
2. **Install extensions**: Make sure Jupyter extension is installed and enabled
3. **Restart VSCode**: Sometimes the UI needs a refresh
4. **Check if notebook is recognized**: VSCode should show "Jupyter" in the status bar when notebook is open

## Alternative: Use Jupyter in Browser

If VSCode continues to be problematic, you can always use Jupyter in the browser:

```bash
cd /home/chlj/nvspark/yolov5
source ../agenttorch_env/bin/activate
jupyter notebook tutorial.ipynb
```

This will open the notebook in your web browser where kernel selection is more obvious.

