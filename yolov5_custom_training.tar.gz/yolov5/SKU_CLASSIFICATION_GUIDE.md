# SKU Classification Guide - 19 Categories

## Overview

This guide explains how to train YOLOv5 for **image classification** with 19 SKU categories. Unlike object detection (which uses bounding boxes), classification assigns each entire image to one of 19 SKU categories.

## Dataset Structure

For classification, organize your images in folders by category name:

```
datasets/
  sku_classification/
    train/
      SKU_001/          # Folder name = category name
        image1.jpg
        image2.jpg
        image3.jpg
        ...
      SKU_002/
        image1.jpg
        image2.jpg
        ...
      SKU_003/
        ...
      ... (all 19 SKU categories)
    val/
      SKU_001/          # Same folder structure
        image1.jpg
        ...
      SKU_002/
        ...
      ... (all 19 SKU categories)
```

## Key Points

1. **No bounding boxes needed** - Just organize images into folders
2. **Folder name = Category name** - The folder name becomes the class label
3. **One image = One category** - Each image belongs to exactly one SKU category
4. **Automatic labeling** - YOLOv5 automatically uses folder names as labels

## Step-by-Step Setup

**Note:** All paths in this notebook are relative, making it portable. Simply run the notebook from the yolov5 root directory.

### 1. Create Directory Structure

```bash
# Navigate to your yolov5 directory
cd path/to/yolov5

# Create dataset directories
mkdir -p datasets/sku_classification/train
mkdir -p datasets/sku_classification/val

# Create folders for each of your 19 SKU categories
for i in {1..19}; do
    mkdir -p datasets/sku_classification/train/SKU_$(printf "%03d" $i)
    mkdir -p datasets/sku_classification/val/SKU_$(printf "%03d" $i)
done
```

Or manually create folders with your actual SKU names:
```bash
# Example with custom SKU names
mkdir -p datasets/sku_classification/train/{Product_A,Product_B,Product_C,...,Product_S}
mkdir -p datasets/sku_classification/val/{Product_A,Product_B,Product_C,...,Product_S}
```

### 2. Organize Your Images

Place each image in the folder corresponding to its SKU category:

```bash
# Example: Move images to appropriate folders
# Image showing SKU_001 product → datasets/sku_classification/train/SKU_001/
# Image showing SKU_002 product → datasets/sku_classification/train/SKU_002/
# etc.
```

**Important:**
- Use consistent folder names between `train/` and `val/`
- Folder names will be used as class labels
- Images can be `.jpg`, `.png`, `.jpeg`

### 3. Update SKU Category Names in Notebook

In the notebook (`tutorial.ipynb`), Cell 11, update the `SKU_CATEGORIES` list with your actual SKU names:

```python
SKU_CATEGORIES = [
    "Product_A",      # Replace with your actual SKU names
    "Product_B",
    "Product_C",
    # ... all 19 categories
    "Product_S"
]
```

**Note:** The folder names must match the names in `SKU_CATEGORIES` (or vice versa).

### 4. Split Your Data

Recommended split:
- **Training**: 70-80% of images per category
- **Validation**: 20-30% of images per category

Example script to split data:
```python
import shutil
from pathlib import Path
import random

# Set random seed for reproducibility
random.seed(42)

source_dir = Path("your_images_directory")
train_dir = Path("datasets/sku_classification/train")
val_dir = Path("datasets/sku_classification/val")

# For each SKU category
for sku in SKU_CATEGORIES:
    # Get all images for this SKU
    images = list(source_dir.glob(f"{sku}/*.jpg")) + \
             list(source_dir.glob(f"{sku}/*.png"))

    # Shuffle
    random.shuffle(images)

    # Split 80/20
    split_idx = int(len(images) * 0.8)
    train_images = images[:split_idx]
    val_images = images[split_idx:]

    # Copy to appropriate folders
    for img in train_images:
        shutil.copy(img, train_dir / sku / img.name)
    for img in val_images:
        shutil.copy(img, val_dir / sku / img.name)
```

## Training

### Using the Notebook

1. Open `tutorial.ipynb`
2. In **Cell 11**, set:
   ```python
   TASK_TYPE = "classification"
   ```
3. Update `SKU_CATEGORIES` with your 19 actual SKU names
4. Run cells 1-13 to verify dataset
5. In **Cell 15**, choose training mode:
   - `TRAIN_FROM_SCRATCH = True` → Train from scratch
   - `TRAIN_FROM_SCRATCH = False` → Transfer learning (recommended)
6. Run Cell 15 to start training

### Using Command Line

**From scratch:**
```bash
python classify/train.py \
  --data datasets/sku_classification \
  --model yolov5s-cls.yaml \
  --weights '' \
  --epochs 100 \
  --img 224 \
  --batch 32 \
  --name sku_classification
```

**From pretrained (recommended):**
```bash
python classify/train.py \
  --data datasets/sku_classification \
  --model yolov5s-cls.pt \
  --epochs 50 \
  --img 224 \
  --batch 32 \
  --name sku_classification
```

## Model Options

Available YOLOv5 classification models:
- `yolov5n-cls.pt` - Nano (smallest, fastest)
- `yolov5s-cls.pt` - Small (recommended for most cases)
- `yolov5m-cls.pt` - Medium
- `yolov5l-cls.pt` - Large
- `yolov5x-cls.pt` - Extra Large (most accurate, slowest)

## Results

After training, results are saved to:
```
runs/train-cls/sku_classification/
  ├── weights/
  │   ├── best.pt      # Best model (highest accuracy)
  │   └── last.pt      # Latest model
  ├── results.png      # Training curves
  └── ...
```

## Inference

After training, classify new images:

```python
import torch

# Load your trained model
model = torch.hub.load('ultralytics/yolov5', 'custom',
                       path='runs/train-cls/sku_classification/weights/best.pt')

# Classify an image
results = model('path/to/image.jpg')
results.print()  # Shows predicted SKU category
```

Or using command line:
```bash
python classify/predict.py \
  --weights runs/train-cls/sku_classification/weights/best.pt \
  --source path/to/images/
```

## Tips

1. **Start with transfer learning** - Use pretrained weights (`yolov5s-cls.pt`) for faster convergence
2. **Balanced dataset** - Try to have similar number of images per category
3. **More images = better** - Aim for at least 50-100 images per category for good results
4. **Image quality** - Use clear, well-lit images
5. **Consistent naming** - Use the same folder names in train and val
6. **Data augmentation** - YOLOv5 automatically augments data during training

## Troubleshooting

### "No category folders found"
- Check that folders are directly under `train/` and `val/`
- Ensure folder names match your SKU categories

### "No images found"
- Check image file extensions (`.jpg`, `.png`, `.jpeg`)
- Verify images are inside category folders, not in parent directories

### Low accuracy
- Add more training images per category
- Ensure images are representative of each SKU
- Try a larger model (yolov5m-cls, yolov5l-cls)
- Train for more epochs

### Out of memory
- Reduce batch size: `--batch 16` or `--batch 8`
- Use smaller model: `yolov5n-cls.pt`
- Reduce image size: `--img 128` (though 224 is standard)

## Example: Complete Workflow

```bash
# 1. Create structure
mkdir -p datasets/sku_classification/{train,val}
cd datasets/sku_classification

# 2. Create 19 category folders
for i in {1..19}; do
    mkdir -p train/SKU_$(printf "%03d" $i)
    mkdir -p val/SKU_$(printf "%03d" $i)
done

# 3. Copy your images to appropriate folders
# (Do this manually or with a script)

# 4. Train (from yolov5 root directory)
python classify/train.py \
  --data datasets/sku_classification \
  --model yolov5s-cls.pt \
  --epochs 50 \
  --img 224 \
  --batch 32 \
  --name sku_classification
```

## Next Steps

1. ✅ Organize images into 19 category folders
2. ✅ Update `SKU_CATEGORIES` in notebook
3. ✅ Run verification (Cell 13)
4. ✅ Train model (Cell 15)
5. ✅ Test on new images

---

**You're ready to classify images into 19 SKU categories!** 🚀

