# Quick Kernel Setup for VSCode

## Fastest Method: Command Palette

1. **Open the notebook** in VSCode: `tutorial.ipynb`

2. **Press**: `Ctrl+Shift+P` (Windows/Linux) or `Cmd+Shift+P` (Mac)

3. **Type exactly**: `Notebook: Select Notebook Kernel`

4. **Press Enter**

5. **Select one of these**:
   - `Python (agenttorch_env)` ← This should appear
   - Or: `/home/chlj/nvspark/agenttorch_env/bin/python` ← Full path

## Verify It Worked

After selecting, create a new cell and run:

```python
import sys
print("✅ Kernel:", sys.executable)
```

You should see:
```
✅ Kernel: /home/chlj/nvspark/agenttorch_env/bin/python
```

## If "Notebook: Select Notebook Kernel" Doesn't Appear

The Jupyter extension might not be installed:

1. Press `Ctrl+Shift+X` (Extensions)
2. Search: `Jupyter`
3. Install: **"Jupyter" by Microsoft**
4. Reload VSCode
5. Try again

## Alternative: Status Bar

Look at the **very bottom** of VSCode window. You should see something like:

```
Python 3.12.3 ▼
```

Click on it to change the kernel.

## Still Stuck?

Run this command in terminal to verify kernel is registered:

```bash
jupyter kernelspec list
```

You should see `agenttorch_env` in the list.

If not, run:
```bash
cd /home/chlj/nvspark
source agenttorch_env/bin/activate
python -m ipykernel install --user --name=agenttorch_env --display-name="Python (agenttorch_env)"
```

Then restart VSCode.

